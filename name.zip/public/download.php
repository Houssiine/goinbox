<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';

$slug = basename($_SERVER['REQUEST_URI']);
$config = load_config();
$lang = load_language($config['default_language']);
$error = '';
$show_password_form = false;
$show_captcha = false;

$file = get_file_by_slug($slug);

if (!$file) {
    http_response_code(404);
    $error = t('file_not_found', $lang);
} elseif (is_expired($file['expiry'])) {
    delete_file_by_hash($file['hash']);
    http_response_code(404);
    $error = t('file_not_found', $lang);
} elseif ($file['max_downloads'] > 0 && $file['download_count'] >= $file['max_downloads']) {
    delete_file_by_hash($file['hash']);
    http_response_code(410);
    $error = 'Download limit reached';
} else {
    if ($file['password_protected'] && !isset($_SESSION['authenticated_' . $slug])) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
            if (password_verify($_POST['password'], $file['password'])) {
                $_SESSION['authenticated_' . $slug] = true;
            } else {
                $error = t('incorrect_password', $lang);
                $show_password_form = true;
            }
        } else {
            $show_password_form = true;
        }
    }
    
    if (!$show_password_form && $config['captcha_enabled'] && !isset($_SESSION['captcha_verified_' . $slug])) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_answer'])) {
            $expected = $_SESSION['captcha_answer'] ?? 0;
            if (intval($_POST['captcha_answer']) === $expected) {
                $_SESSION['captcha_verified_' . $slug] = true;
            } else {
                $error = t('captcha_incorrect', $lang);
                $show_captcha = true;
            }
        } else {
            $show_captcha = true;
        }
    }
    
    if (!$show_password_form && !$show_captcha && !$error) {
        if (isset($_GET['download'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
            
            if (!check_rate_limit($ip, $config)) {
                http_response_code(429);
                $error = t('rate_limit_exceeded', $lang);
            } else {
                $file['download_count']++;
                save_file_meta($file['hash'], $file);
                log_access($slug, 'download', $ip);
                
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
                header('Content-Length: ' . $file['size']);
                header('Cache-Control: no-cache');
                
                if ($config['bandwidth_limit_kbps'] > 0) {
                    $handle = fopen($file['path'], 'rb');
                    $chunk_size = $config['bandwidth_limit_kbps'] * 1024;
                    while (!feof($handle)) {
                        echo fread($handle, $chunk_size);
                        flush();
                        sleep(1);
                    }
                    fclose($handle);
                } else {
                    readfile($file['path']);
                }
                
                if ($file['max_downloads'] > 0 && $file['download_count'] >= $file['max_downloads']) {
                    delete_file_by_hash($file['hash']);
                }
                
                exit;
            }
        }
    }
}

if ($show_captcha) {
    $num1 = rand(1, 10);
    $num2 = rand(1, 10);
    $_SESSION['captcha_answer'] = $num1 + $num2;
}
?>
<!DOCTYPE html>
<html lang="<?php echo $config['default_language']; ?>" dir="<?php echo $config['default_language'] === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $file ? htmlspecialchars($file['original_name']) : '404'; ?> - <?php echo t('site_title', $lang); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        body { padding: 2rem; }
        .container { max-width: 600px; margin: 50px auto; }
        .error { color: #d32f2f; background: #ffebee; padding: 1rem; border-radius: 0.25rem; margin-bottom: 1rem; }
        .file-info { background: var(--pico-card-background-color); padding: 1.5rem; border-radius: 0.5rem; margin-bottom: 1rem; }
        .preview { margin-top: 1rem; text-align: center; }
        .preview img { max-width: 100%; border-radius: 0.5rem; }
        .preview iframe { width: 100%; height: 600px; border: none; border-radius: 0.5rem; }
    </style>
</head>
<body>
    <main class="container">
        <article>
            <header>
                <h1><?php echo t('site_title', $lang); ?></h1>
            </header>
            
            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php elseif ($show_password_form): ?>
                <h2><?php echo t('password_required', $lang); ?></h2>
                <p><?php echo t('enter_password', $lang); ?></p>
                <form method="POST">
                    <input type="password" name="password" placeholder="<?php echo t('password', $lang); ?>" required autofocus>
                    <button type="submit"><?php echo t('download', $lang); ?></button>
                </form>
            <?php elseif ($show_captcha): ?>
                <h2><?php echo t('captcha', $lang); ?></h2>
                <form method="POST">
                    <label>
                        <?php echo t('captcha_question', $lang); ?> <?php echo $num1; ?> + <?php echo $num2; ?>?
                        <input type="number" name="captcha_answer" required autofocus>
                    </label>
                    <button type="submit"><?php echo t('download', $lang); ?></button>
                </form>
            <?php elseif ($file): ?>
                <div class="file-info">
                    <h2><?php echo htmlspecialchars($file['original_name']); ?></h2>
                    <p>
                        <strong><?php echo t('file_size', $lang); ?>:</strong> <?php echo format_bytes($file['size']); ?><br>
                        <strong><?php echo t('downloads', $lang); ?>:</strong> <?php echo $file['download_count']; ?>
                        <?php if ($file['max_downloads'] > 0): ?>
                            / <?php echo $file['max_downloads']; ?>
                        <?php endif; ?>
                        <br>
                        <?php if ($file['expiry'] > 0): ?>
                            <strong><?php echo t('expiry', $lang); ?>:</strong> <?php echo date('Y-m-d H:i', $file['expiry']); ?>
                        <?php endif; ?>
                    </p>
                    <a href="?download=1" role="button"><?php echo t('download', $lang); ?></a>
                </div>

                <?php if (can_preview($file['mime'])): ?>
                    <div class="preview">
                        <?php if (strpos($file['mime'], 'image/') === 0): ?>
                            <img src="data:<?php echo $file['mime']; ?>;base64,<?php echo base64_encode(file_get_contents($file['path'])); ?>" alt="Preview">
                        <?php elseif ($file['mime'] === 'application/pdf'): ?>
                            <iframe src="data:<?php echo $file['mime']; ?>;base64,<?php echo base64_encode(file_get_contents($file['path'])); ?>"></iframe>
                        <?php elseif (strpos($file['mime'], 'text/') === 0): ?>
                            <pre style="text-align: left; background: var(--pico-code-background-color); padding: 1rem; border-radius: 0.5rem; overflow-x: auto;"><?php echo htmlspecialchars(file_get_contents($file['path'])); ?></pre>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </article>
    </main>
</body>
</html>
