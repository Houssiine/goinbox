<?php
require_once __DIR__ . '/includes/functions.php';

if (!is_logged_in()) {
    die('Unauthorized access');
}

function create_backup() {
    $backup_dir = __DIR__ . '/backups';
    if (!is_dir($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    $date = date('Y-m-d_H-i-s');
    $backup_file = $backup_dir . '/backup_' . $date . '.zip';
    
    $zip = new ZipArchive();
    if ($zip->open($backup_file, ZipArchive::CREATE) !== TRUE) {
        return ['success' => false, 'message' => 'Cannot create ZIP file'];
    }
    
    $directories = ['data', 'config', 'logs'];
    
    foreach ($directories as $dir) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(__DIR__ . '/' . $dir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }
    
    $zip->close();
    
    return [
        'success' => true,
        'file' => basename($backup_file),
        'size' => filesize($backup_file),
        'path' => $backup_file
    ];
}

function restore_backup($backup_file) {
    $zip = new ZipArchive();
    if ($zip->open($backup_file) !== TRUE) {
        return ['success' => false, 'message' => 'Cannot open backup file'];
    }
    
    $zip->extractTo(__DIR__ . '/');
    $zip->close();
    
    return ['success' => true, 'message' => 'Backup restored successfully'];
}

function list_backups() {
    $backup_dir = __DIR__ . '/backups';
    if (!is_dir($backup_dir)) {
        return [];
    }
    
    $backups = [];
    $files = glob($backup_dir . '/backup_*.zip');
    
    foreach ($files as $file) {
        $backups[] = [
            'name' => basename($file),
            'size' => filesize($file),
            'date' => filemtime($file)
        ];
    }
    
    usort($backups, function($a, $b) {
        return $b['date'] - $a['date'];
    });
    
    return $backups;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                echo json_encode(create_backup());
                break;
                
            case 'restore':
                if (isset($_FILES['backup_file'])) {
                    $tmp = $_FILES['backup_file']['tmp_name'];
                    echo json_encode(restore_backup($tmp));
                }
                break;
                
            case 'list':
                echo json_encode(list_backups());
                break;
                
            case 'download':
                if (isset($_POST['filename'])) {
                    $file = __DIR__ . '/backups/' . basename($_POST['filename']);
                    if (file_exists($file)) {
                        header('Content-Type: application/zip');
                        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
                        header('Content-Length: ' . filesize($file));
                        readfile($file);
                        exit;
                    }
                }
                break;
        }
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Backup & Restore</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        .container { max-width: 800px; margin: 2rem auto; }
        .backup-item { display: flex; justify-content: space-between; align-items: center; padding: 1rem; background: var(--pico-card-background-color); margin-bottom: 0.5rem; border-radius: 0.5rem; }
    </style>
</head>
<body>
    <main class="container">
        <h1>Backup & Restore</h1>
        
        <section>
            <h2>Create Backup</h2>
            <button onclick="createBackup()">Create New Backup</button>
            <div id="backup-status"></div>
        </section>
        
        <section>
            <h2>Restore Backup</h2>
            <input type="file" id="restoreFile" accept=".zip">
            <button onclick="restoreBackup()">Restore from File</button>
        </section>
        
        <section>
            <h2>Available Backups</h2>
            <div id="backup-list"></div>
        </section>
    </main>
    
    <script>
        function createBackup() {
            const status = document.getElementById('backup-status');
            status.innerHTML = 'Creating backup...';
            
            fetch('backup.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=create'
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    status.innerHTML = `Backup created: ${data.file} (${formatBytes(data.size)})`;
                    loadBackups();
                } else {
                    status.innerHTML = 'Error: ' + data.message;
                }
            });
        }
        
        function restoreBackup() {
            const file = document.getElementById('restoreFile').files[0];
            if (!file) return alert('Select a backup file');
            
            const formData = new FormData();
            formData.append('action', 'restore');
            formData.append('backup_file', file);
            
            fetch('backup.php', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                alert(data.message);
                if (data.success) location.reload();
            });
        }
        
        function loadBackups() {
            fetch('backup.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=list'
            })
            .then(r => r.json())
            .then(backups => {
                const list = document.getElementById('backup-list');
                list.innerHTML = backups.map(b => `
                    <div class="backup-item">
                        <div>
                            <strong>${b.name}</strong><br>
                            <small>${new Date(b.date * 1000).toLocaleString()} - ${formatBytes(b.size)}</small>
                        </div>
                        <button onclick="downloadBackup('${b.name}')">Download</button>
                    </div>
                `).join('');
            });
        }
        
        function downloadBackup(filename) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'backup.php';
            form.innerHTML = `
                <input type="hidden" name="action" value="download">
                <input type="hidden" name="filename" value="${filename}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
        
        function formatBytes(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }
        
        loadBackups();
    </script>
</body>
</html>
