<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    header('Location: /admin/');
    exit;
}

$config = load_config();
$lang = load_language($config['default_language']);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($email === $config['admin_email'] && password_verify($password, $config['admin_password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_email'] = $email;
        header('Location: /admin/');
        exit;
    } else {
        $error = t('invalid_login', $lang);
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $config['default_language']; ?>" dir="<?php echo $config['default_language'] === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('login', $lang); ?> - <?php echo t('site_title', $lang); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        body { padding: 2rem; }
        .container { max-width: 400px; margin: 100px auto; }
        .error { color: #d32f2f; background: #ffebee; padding: 0.75rem; border-radius: 0.25rem; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <main class="container">
        <article>
            <header>
                <h1><?php echo t('site_title', $lang); ?></h1>
                <p><?php echo t('login', $lang); ?></p>
            </header>
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST">
                <input type="email" name="email" placeholder="<?php echo t('email', $lang); ?>" required autofocus>
                <input type="password" name="password" placeholder="<?php echo t('password', $lang); ?>" required>
                <button type="submit"><?php echo t('login', $lang); ?></button>
            </form>
        </article>
    </main>
</body>
</html>
