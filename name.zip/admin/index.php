<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();

$config = load_config();
$lang = load_language($config['default_language']);
$stats = get_stats();
$files = get_all_files();
$message = $_GET['msg'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verify_csrf($_POST['csrf_token'])) {
        die('CSRF validation failed');
    }
    
    if ($_POST['action'] === 'delete' && isset($_POST['hash'])) {
        delete_file_by_hash($_POST['hash']);
        log_access('', 'admin_delete', $_POST['hash']);
        header('Location: /admin/?msg=deleted');
        exit;
    }
    
    if ($_POST['action'] === 'bulk_delete' && isset($_POST['selected'])) {
        foreach ($_POST['selected'] as $hash) {
            delete_file_by_hash($hash);
        }
        header('Location: /admin/?msg=bulk_deleted');
        exit;
    }
    
    if ($_POST['action'] === 'cleanup') {
        $cleaned = cleanup_expired_files();
        header('Location: /admin/?msg=cleaned_' . $cleaned);
        exit;
    }
}

$search = $_GET['search'] ?? '';
if ($search) {
    $files = array_filter($files, function($file) use ($search) {
        return stripos($file['original_name'], $search) !== false;
    });
}
?>
<!DOCTYPE html>
<html lang="<?php echo $config['default_language']; ?>" dir="<?php echo $config['default_language'] === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('dashboard', $lang); ?> - <?php echo t('site_title', $lang); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        nav { margin-bottom: 2rem; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: var(--pico-card-background-color); padding: 1.5rem; border-radius: 0.5rem; text-align: center; }
        .stat-value { font-size: 2rem; font-weight: bold; color: var(--pico-primary); }
        .stat-label { color: var(--pico-muted-color); font-size: 0.875rem; margin-top: 0.5rem; }
        table { width: 100%; font-size: 0.875rem; }
        .actions { display: flex; gap: 0.5rem; }
        .actions button { padding: 0.25rem 0.5rem; font-size: 0.75rem; margin: 0; }
        .success { background: #e8f5e9; color: #2e7d32; padding: 1rem; border-radius: 0.25rem; margin-bottom: 1rem; }
        .toolbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; gap: 1rem; flex-wrap: wrap; }
        .search-box { flex: 1; min-width: 200px; }
    </style>
</head>
<body>
    <nav class="container-fluid">
        <ul>
            <li><strong><?php echo t('site_title', $lang); ?></strong></li>
        </ul>
        <ul>
            <li><a href="/admin/"><?php echo t('dashboard', $lang); ?></a></li>
            <li><a href="/admin/upload.php"><?php echo t('upload', $lang); ?></a></li>
            <li><a href="/admin/settings.php"><?php echo t('settings', $lang); ?></a></li>
            <li><a href="/admin/logout.php"><?php echo t('logout', $lang); ?></a></li>
        </ul>
    </nav>

    <main class="container">
        <?php if ($message === 'deleted'): ?>
            <div class="success"><?php echo t('file_deleted', $lang); ?></div>
        <?php elseif (str_starts_with($message, 'cleaned_')): ?>
            <div class="success"><?php echo substr($message, 8) . ' ' . t('files_cleaned', $lang); ?></div>
        <?php endif; ?>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['total_files']; ?></div>
                <div class="stat-label"><?php echo t('total_files', $lang); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['total_downloads']; ?></div>
                <div class="stat-label"><?php echo t('total_downloads', $lang); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['total_size_formatted']; ?></div>
                <div class="stat-label"><?php echo t('total_storage', $lang); ?></div>
            </div>
        </div>

        <div class="toolbar">
            <form method="GET" class="search-box">
                <input type="search" name="search" placeholder="<?php echo t('search', $lang); ?>" value="<?php echo htmlspecialchars($search); ?>">
            </form>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="action" value="cleanup">
                <button type="submit" class="secondary"><?php echo t('cleanup_expired', $lang); ?></button>
            </form>
        </div>

        <form method="POST" id="fileForm">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <input type="hidden" name="action" value="bulk_delete">
            
            <?php if (count($files) > 0): ?>
                <button type="submit" class="secondary" onclick="return confirm('Delete selected files?')"><?php echo t('bulk_delete', $lang); ?></button>
            <?php endif; ?>

            <figure>
                <table role="grid">
                    <thead>
                        <tr>
                            <th><input type="checkbox" onclick="document.querySelectorAll('input[name=\'selected[]\']').forEach(e => e.checked = this.checked)"></th>
                            <th><?php echo t('file_name', $lang); ?></th>
                            <th><?php echo t('file_size', $lang); ?></th>
                            <th><?php echo t('downloads', $lang); ?></th>
                            <th><?php echo t('created', $lang); ?></th>
                            <th><?php echo t('expiry', $lang); ?></th>
                            <th><?php echo t('actions', $lang); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($files)): ?>
                            <tr><td colspan="7" style="text-align: center;">No files uploaded yet</td></tr>
                        <?php else: ?>
                            <?php foreach ($files as $file): ?>
                                <tr>
                                    <td><input type="checkbox" name="selected[]" value="<?php echo $file['hash']; ?>"></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($file['original_name']); ?></strong>
                                        <?php if ($file['password_protected']): ?> 🔒<?php endif; ?>
                                    </td>
                                    <td><?php echo format_bytes($file['size']); ?></td>
                                    <td>
                                        <?php echo $file['download_count']; ?>
                                        <?php if ($file['max_downloads'] > 0): ?>
                                            / <?php echo $file['max_downloads']; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', $file['created']); ?></td>
                                    <td>
                                        <?php if ($file['expiry'] == 0): ?>
                                            <?php echo t('never', $lang); ?>
                                        <?php elseif (is_expired($file['expiry'])): ?>
                                            <span style="color: red;"><?php echo t('expired', $lang); ?></span>
                                        <?php else: ?>
                                            <?php echo date('Y-m-d H:i', $file['expiry']); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button type="button" class="secondary" onclick="copyLink('<?php echo $file['slug']; ?>')"><?php echo t('copy_link', $lang); ?></button>
                                            <button type="button" class="secondary" onclick="deleteFile('<?php echo $file['hash']; ?>')"><?php echo t('delete', $lang); ?></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </figure>
        </form>
    </main>

    <script>
        function copyLink(slug) {
            const url = window.location.origin + '/' + slug;
            navigator.clipboard.writeText(url).then(() => {
                alert('Link copied: ' + url);
            });
        }

        function deleteFile(hash) {
            if (confirm('Delete this file?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="hash" value="${hash}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>
