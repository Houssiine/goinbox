<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();

$config = load_config();
$lang = load_language($config['default_language']);
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
    if (!verify_csrf($_POST['csrf_token'])) {
        die('CSRF validation failed');
    }
    
    $custom_slug = trim($_POST['custom_slug'] ?? '');
    $expiry_hours = intval($_POST['expiry_hours'] ?? $config['default_expiry_hours']);
    $link_password = $_POST['link_password'] ?? '';
    $max_downloads = intval($_POST['max_downloads'] ?? 0);
    
    $uploaded_files = [];
    
    foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
            $original_name = sanitize_filename($_FILES['files']['name'][$key]);
            $file_size = $_FILES['files']['size'][$key];
            
            if ($file_size > $config['max_file_size']) {
                $error = "File too large: $original_name";
                continue;
            }
            
            $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
            if (!in_array($ext, $config['allowed_extensions'])) {
                $error = "Extension not allowed: $ext";
                continue;
            }
            
            $hash = generate_hash($tmp_name);
            
            $year = date('Y');
            $month = date('m');
            $upload_dir = __DIR__ . "/../data/uploads/$year/$month";
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $stored_filename = $hash . '-' . $original_name;
            $destination = $upload_dir . '/' . $stored_filename;
            
            if (move_uploaded_file($tmp_name, $destination)) {
                $slug = !empty($custom_slug) ? $custom_slug : generate_slug();
                $expiry = $expiry_hours > 0 ? time() + ($expiry_hours * 3600) : 0;
                
                $meta = [
                    'hash' => $hash,
                    'slug' => $slug,
                    'original_name' => $original_name,
                    'stored_name' => $stored_filename,
                    'path' => $destination,
                    'size' => $file_size,
                    'mime' => get_mime_type($destination),
                    'created' => time(),
                    'expiry' => $expiry,
                    'password' => !empty($link_password) ? password_hash($link_password, PASSWORD_BCRYPT) : '',
                    'password_protected' => !empty($link_password),
                    'max_downloads' => $max_downloads,
                    'download_count' => 0
                ];
                
                save_file_meta($hash, $meta);
                log_access($slug, 'upload', $original_name);
                $uploaded_files[] = [
                    'name' => $original_name,
                    'slug' => $slug,
                    'url' => 'https://' . $_SERVER['HTTP_HOST'] . '/' . $slug
                ];
            }
        }
    }
    
    if (count($uploaded_files) > 0) {
        $success = $uploaded_files;
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $config['default_language']; ?>" dir="<?php echo $config['default_language'] === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('upload', $lang); ?> - <?php echo t('site_title', $lang); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        nav { margin-bottom: 2rem; }
        .drop-zone {
            border: 3px dashed var(--pico-muted-border-color);
            border-radius: 0.5rem;
            padding: 3rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: var(--pico-card-background-color);
        }
        .drop-zone.dragging {
            border-color: var(--pico-primary);
            background: var(--pico-primary-background);
        }
        .drop-zone:hover {
            border-color: var(--pico-primary);
        }
        .file-list { margin-top: 1rem; }
        .file-item { padding: 0.5rem; background: var(--pico-card-background-color); margin-bottom: 0.5rem; border-radius: 0.25rem; }
        .success-box { background: #e8f5e9; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem; }
        .link-item { display: flex; justify-content: space-between; align-items: center; padding: 0.75rem; background: white; margin: 0.5rem 0; border-radius: 0.25rem; }
        .error-box { background: #ffebee; color: #c62828; padding: 1rem; border-radius: 0.5rem; margin-top: 1rem; }
    </style>
</head>
<body>
    <nav class="container-fluid">
        <ul>
            <li><strong><?php echo t('site_title', $lang); ?></strong></li>
        </ul>
        <ul>
            <li><a href="/admin/"><?php echo t('dashboard', $lang); ?></a></li>
            <li><a href="/admin/upload.php"><?php echo t('upload', $lang); ?></a></li>
            <li><a href="/admin/settings.php"><?php echo t('settings', $lang); ?></a></li>
            <li><a href="/admin/logout.php"><?php echo t('logout', $lang); ?></a></li>
        </ul>
    </nav>

    <main class="container">
        <h2><?php echo t('upload_files', $lang); ?></h2>

        <?php if ($error): ?>
            <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-box">
                <h3><?php echo t('link_generated', $lang); ?></h3>
                <?php foreach ($success as $file): ?>
                    <div class="link-item">
                        <div>
                            <strong><?php echo htmlspecialchars($file['name']); ?></strong><br>
                            <small><?php echo $file['url']; ?></small>
                        </div>
                        <button class="secondary" onclick="copyToClipboard('<?php echo $file['url']; ?>')"><?php echo t('copy', $lang); ?></button>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" id="uploadForm">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            
            <div class="drop-zone" id="dropZone">
                <p style="font-size: 1.5rem; margin-bottom: 1rem;">📁</p>
                <p><?php echo t('drag_drop', $lang); ?></p>
                <input type="file" name="files[]" id="fileInput" multiple style="display: none;">
            </div>

            <div class="file-list" id="fileList"></div>

            <div class="grid">
                <label>
                    <?php echo t('custom_slug', $lang); ?>
                    <input type="text" name="custom_slug" placeholder="my-file" pattern="[a-zA-Z0-9_-]+">
                </label>
                <label>
                    <?php echo t('expiry_hours', $lang); ?>
                    <input type="number" name="expiry_hours" value="<?php echo $config['default_expiry_hours']; ?>" min="0">
                </label>
            </div>

            <div class="grid">
                <label>
                    <?php echo t('link_password', $lang); ?>
                    <input type="password" name="link_password">
                </label>
                <label>
                    <?php echo t('max_downloads', $lang); ?>
                    <input type="number" name="max_downloads" value="0" min="0">
                </label>
            </div>

            <button type="submit" id="submitBtn" disabled><?php echo t('upload_button', $lang); ?></button>
        </form>
    </main>

    <script>
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const fileList = document.getElementById('fileList');
        const submitBtn = document.getElementById('submitBtn');

        dropZone.addEventListener('click', () => fileInput.click());

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragging');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragging');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragging');
            fileInput.files = e.dataTransfer.files;
            updateFileList();
        });

        fileInput.addEventListener('change', updateFileList);

        function updateFileList() {
            fileList.innerHTML = '';
            const files = fileInput.files;
            
            if (files.length > 0) {
                submitBtn.disabled = false;
                for (let file of files) {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    div.textContent = `${file.name} (${formatBytes(file.size)})`;
                    fileList.appendChild(div);
                }
            } else {
                submitBtn.disabled = true;
            }
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('<?php echo t('copy', $lang); ?>: ' + text);
            });
        }
    </script>
</body>
</html>
