<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_login();

$config = load_config();
$lang = load_language($config['default_language']);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'])) {
        die('CSRF validation failed');
    }
    
    $config['site_name'] = $_POST['site_name'];
    $config['admin_email'] = $_POST['admin_email'];
    $config['max_file_size'] = intval($_POST['max_file_size']) * 1048576;
    $config['default_expiry_hours'] = intval($_POST['default_expiry_hours']);
    $config['captcha_enabled'] = isset($_POST['captcha_enabled']);
    $config['rate_limit_downloads'] = intval($_POST['rate_limit_downloads']);
    $config['rate_limit_hours'] = intval($_POST['rate_limit_hours']);
    $config['bandwidth_limit_kbps'] = intval($_POST['bandwidth_limit_kbps']);
    $config['default_language'] = $_POST['default_language'];
    $config['timezone'] = $_POST['timezone'];
    
    if (!empty($_POST['new_password'])) {
        $config['admin_password'] = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
    }
    
    $extensions = array_map('trim', explode(',', $_POST['allowed_extensions']));
    $config['allowed_extensions'] = array_filter($extensions);
    
    save_config($config);
    $message = t('settings_updated', $lang);
    $lang = load_language($config['default_language']);
}

$timezones = timezone_identifiers_list();
?>
<!DOCTYPE html>
<html lang="<?php echo $config['default_language']; ?>" dir="<?php echo $config['default_language'] === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo t('settings', $lang); ?> - <?php echo t('site_title', $lang); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <style>
        nav { margin-bottom: 2rem; }
        .success { background: #e8f5e9; color: #2e7d32; padding: 1rem; border-radius: 0.25rem; margin-bottom: 1rem; }
        .section { margin-bottom: 2rem; padding: 1.5rem; background: var(--pico-card-background-color); border-radius: 0.5rem; }
        .section h3 { margin-top: 0; }
    </style>
</head>
<body>
    <nav class="container-fluid">
        <ul>
            <li><strong><?php echo t('site_title', $lang); ?></strong></li>
        </ul>
        <ul>
            <li><a href="/admin/"><?php echo t('dashboard', $lang); ?></a></li>
            <li><a href="/admin/upload.php"><?php echo t('upload', $lang); ?></a></li>
            <li><a href="/admin/settings.php"><?php echo t('settings', $lang); ?></a></li>
            <li><a href="/admin/logout.php"><?php echo t('logout', $lang); ?></a></li>
        </ul>
    </nav>

    <main class="container">
        <h2><?php echo t('settings', $lang); ?></h2>

        <?php if ($message): ?>
            <div class="success"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

            <div class="section">
                <h3>General Settings</h3>
                <label>
                    Site Name
                    <input type="text" name="site_name" value="<?php echo htmlspecialchars($config['site_name']); ?>" required>
                </label>
                
                <div class="grid">
                    <label>
                        Default Language
                        <select name="default_language">
                            <option value="en" <?php echo $config['default_language'] === 'en' ? 'selected' : ''; ?>>English</option>
                            <option value="ar" <?php echo $config['default_language'] === 'ar' ? 'selected' : ''; ?>>العربية</option>
                            <option value="fr" <?php echo $config['default_language'] === 'fr' ? 'selected' : ''; ?>>Français</option>
                        </select>
                    </label>
                    
                    <label>
                        Timezone
                        <select name="timezone">
                            <?php foreach ($timezones as $tz): ?>
                                <option value="<?php echo $tz; ?>" <?php echo $config['timezone'] === $tz ? 'selected' : ''; ?>>
                                    <?php echo $tz; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </div>
            </div>

            <div class="section">
                <h3>Admin Account</h3>
                <label>
                    Admin Email
                    <input type="email" name="admin_email" value="<?php echo htmlspecialchars($config['admin_email']); ?>" required>
                </label>
                
                <label>
                    New Password (leave empty to keep current)
                    <input type="password" name="new_password" autocomplete="new-password">
                </label>
            </div>

            <div class="section">
                <h3>Upload Settings</h3>
                <label>
                    Max File Size (MB)
                    <input type="number" name="max_file_size" value="<?php echo $config['max_file_size'] / 1048576; ?>" min="1" required>
                </label>
                
                <label>
                    Allowed Extensions (comma-separated)
                    <input type="text" name="allowed_extensions" value="<?php echo implode(', ', $config['allowed_extensions']); ?>" required>
                    <small>Example: pdf, jpg, png, zip</small>
                </label>
                
                <label>
                    Default Expiry (hours, 0 = never)
                    <input type="number" name="default_expiry_hours" value="<?php echo $config['default_expiry_hours']; ?>" min="0" required>
                </label>
            </div>

            <div class="section">
                <h3>Security & Rate Limiting</h3>
                <label>
                    <input type="checkbox" name="captcha_enabled" <?php echo $config['captcha_enabled'] ? 'checked' : ''; ?>>
                    Enable CAPTCHA on downloads
                </label>
                
                <div class="grid">
                    <label>
                        Rate Limit (downloads per period, 0 = unlimited)
                        <input type="number" name="rate_limit_downloads" value="<?php echo $config['rate_limit_downloads']; ?>" min="0">
                    </label>
                    
                    <label>
                        Rate Limit Period (hours)
                        <input type="number" name="rate_limit_hours" value="<?php echo $config['rate_limit_hours']; ?>" min="1">
                    </label>
                </div>
                
                <label>
                    Bandwidth Limit (KB/s, 0 = unlimited)
                    <input type="number" name="bandwidth_limit_kbps" value="<?php echo $config['bandwidth_limit_kbps']; ?>" min="0">
                    <small>Throttle download speed per connection</small>
                </label>
            </div>

            <button type="submit"><?php echo t('save', $lang); ?></button>
        </form>
    </main>
</body>
</html>
