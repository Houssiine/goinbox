# 🚀 Deployment Guide - Private FileHost

This guide will help you deploy the Private FileHost system on your CWP server.

## 📋 Pre-Deployment Checklist

- [ ] CWP (CentOS Web Panel) server ready
- [ ] Domain or subdomain configured (e.g., files.yourdomain.com)
- [ ] PHP 8.1+ installed
- [ ] Apache with mod_rewrite enabled
- [ ] At least 1GB free disk space

## 🎯 Quick Deployment (Recommended)

### Method 1: Automated Installation

1. **Upload all files** to your server:
   ```bash
   # Via SCP
   scp -r filehost/* user@yourserver:/home/username/public_html/files/
   
   # Or via FTP using FileZilla
   # Upload entire filehost folder
   ```

2. **Run the installer**:
   ```bash
   ssh user@yourserver
   cd /home/username/public_html/files/
   sudo bash install.sh
   ```

3. **Follow the prompts**:
   - Enter installation directory
   - Enter your domain
   - Installer will configure everything automatically

4. **Access your site**:
   ```
   http://files.yourdomain.com/admin/
   Email: admin@example.com
   Password: admin123
   ```

5. **Secure your installation**:
   - Login and change password immediately
   - Delete setup.php: `rm setup.php`

---

## 🛠️ Manual Deployment

If you prefer manual setup or the automated installer doesn't work:

### Step 1: Create Directory Structure

```bash
cd /home/username/public_html/
mkdir -p files
cd files
```

### Step 2: Upload Files

Upload all files from the `filehost` folder to this directory using:
- FTP (FileZilla, WinSCP)
- SCP command
- CWP File Manager

### Step 3: Set Permissions

```bash
chmod 755 admin/ public/ includes/ lang/ assets/ -R
chmod 755 data/ config/ logs/ backups/ -R
chmod 644 .htaccess
```

### Step 4: Initialize Application

Visit: `http://files.yourdomain.com/setup.php`

This will:
- Create necessary directories
- Generate default configuration
- Set up admin account

### Step 5: Configure Apache (CWP)

**Option A: Using CWP Panel**

1. Login to CWP: `https://yourserver:2083`
2. Go to **Webserver Settings → Domain Management**
3. Add new domain or subdomain: `files.yourdomain.com`
4. Set document root: `/home/username/public_html/files`
5. Enable SSL (Let's Encrypt)

**Option B: Manual VirtualHost**

Create `/etc/httpd/conf.d/files.yourdomain.com.conf`:

```apache
<VirtualHost *:80>
    ServerName files.yourdomain.com
    DocumentRoot /home/username/public_html/files
    
    <Directory /home/username/public_html/files>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        php_value upload_max_filesize 500M
        php_value post_max_size 500M
        php_value max_execution_time 300
    </Directory>
    
    <DirectoryMatch "^/home/username/public_html/files/(data|config|logs)">
        Require all denied
    </DirectoryMatch>
</VirtualHost>
```

Restart Apache:
```bash
systemctl restart httpd
```

### Step 6: Enable mod_rewrite

Check if enabled:
```bash
httpd -M | grep rewrite
```

If not enabled, add to `/etc/httpd/conf/httpd.conf`:
```apache
LoadModule rewrite_module modules/mod_rewrite.so
```

### Step 7: Configure PHP

Edit `/etc/php.ini` or create `.user.ini` in your directory:

```ini
upload_max_filesize = 500M
post_max_size = 500M
max_execution_time = 300
max_input_time = 300
memory_limit = 256M
```

Restart PHP-FPM:
```bash
systemctl restart php-fpm
```

### Step 8: First Login

1. Visit: `http://files.yourdomain.com/admin/`
2. Login with:
   - Email: `admin@example.com`
   - Password: `admin123`
3. **IMMEDIATELY** go to Settings → Admin Account → Change Password
4. Delete `setup.php` file

---

## 🔒 Security Hardening

### 1. Enable HTTPS

```bash
# Install Certbot
yum install certbot python3-certbot-apache

# Get SSL certificate
certbot --apache -d files.yourdomain.com

# Auto-renewal (already set up by certbot)
certbot renew --dry-run
```

### 2. Firewall Configuration

```bash
# Allow HTTP and HTTPS
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --reload
```

### 3. Restrict Admin Access (Optional)

Edit `.htaccess` in `admin/` folder:

```apache
# Restrict admin panel to specific IPs
<Files "*.php">
    Order Deny,Allow
    Deny from all
    Allow from YOUR.IP.ADDRESS
    Allow from 127.0.0.1
</Files>
```

### 4. Disable Directory Listing

Already configured in `.htaccess`:
```apache
Options -Indexes
```

### 5. Hide PHP Version

Edit `/etc/php.ini`:
```ini
expose_php = Off
```

---

## 📊 Post-Deployment Testing

### Test Checklist:

- [ ] Can access admin panel
- [ ] Can login with default credentials
- [ ] Can change password
- [ ] Can upload a test file
- [ ] Short link works (e.g., `/aBc123`)
- [ ] File preview works (images, PDFs)
- [ ] Password protection works
- [ ] CAPTCHA displays
- [ ] Rate limiting works
- [ ] File deletion works
- [ ] Settings save correctly

### Test Upload:

1. Go to Admin → Upload
2. Upload a test PDF or image
3. Set expiry to 1 hour
4. Add a password
5. Copy the generated link
6. Open link in incognito/private browser
7. Test password prompt
8. Test CAPTCHA
9. Download file
10. Verify in Dashboard

---

## 🔧 Troubleshooting

### Issue: 404 on all pages

**Solution:**
```bash
# Check mod_rewrite
httpd -M | grep rewrite

# Check .htaccess
cat .htaccess

# Check Apache config allows overrides
grep -r "AllowOverride" /etc/httpd/conf/httpd.conf
```

### Issue: Upload fails / File too large

**Solution:**
```bash
# Check PHP limits
php -i | grep upload_max_filesize
php -i | grep post_max_size

# Update limits
echo "upload_max_filesize = 500M" >> /etc/php.ini
echo "post_max_size = 500M" >> /etc/php.ini

# Restart services
systemctl restart php-fpm
systemctl restart httpd
```

### Issue: Permission denied

**Solution:**
```bash
# Fix ownership
chown -R apache:apache /home/username/public_html/files/

# Fix permissions
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod 755 data/ config/ logs/ -R
```

### Issue: Session errors

**Solution:**
```bash
# Create session directory
mkdir -p data/.sessions
chmod 755 data/.sessions
chown apache:apache data/.sessions

# Update php.ini
echo "session.save_path = '/home/username/public_html/files/data/.sessions'" >> /etc/php.ini
systemctl restart php-fpm
```

---

## 📈 Performance Optimization

### 1. Enable OPcache

Edit `/etc/php.ini`:
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=10000
opcache.revalidate_freq=60
```

### 2. Enable Compression

Add to `.htaccess`:
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

### 3. Enable Browser Caching

Add to `.htaccess`:
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

---

## 🔄 Backup & Restore

### Automated Backup

Access: `http://files.yourdomain.com/admin/backup.php`

Features:
- One-click backup creation
- Download backups as ZIP
- Restore from backup
- View all available backups

### Manual Backup

```bash
# Backup everything
cd /home/username/public_html/
tar -czf filehost-backup-$(date +%Y%m%d).tar.gz files/

# Backup only data
cd files/
tar -czf data-backup-$(date +%Y%m%d).tar.gz data/ config/ logs/
```

### Automated Daily Backup (Cron)

```bash
crontab -e

# Add this line for daily backup at 2 AM
0 2 * * * cd /home/username/public_html/files && tar -czf /home/username/backups/filehost-$(date +\%Y\%m\%d).tar.gz data/ config/ logs/
```

---

## 📞 Support & Maintenance

### Regular Maintenance Tasks

**Weekly:**
- Check disk usage
- Review access logs
- Clean expired files

**Monthly:**
- Update PHP if needed
- Review and optimize database (if added later)
- Check for security updates

**Quarterly:**
- Full backup
- Review and update allowed file extensions
- Audit security settings

### Monitoring

Check logs:
```bash
# Access logs
tail -f /var/log/httpd/files.yourdomain.com-access.log

# Error logs
tail -f /var/log/httpd/files.yourdomain.com-error.log

# Application logs
tail -f logs/$(date +%Y-%m-%d).log
```

---

## ✅ Deployment Complete!

Your Private FileHost is now ready to use. Remember to:

1. ✅ Change default password
2. ✅ Delete setup.php
3. ✅ Enable HTTPS
4. ✅ Set up regular backups
5. ✅ Test all features

**Need help?** Check the README.md file for detailed documentation.

---

**Happy file hosting! 🎉**
