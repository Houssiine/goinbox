<?php
// FileHost Setup Script - Run once to initialize directories

$directories = [
    'data/uploads',
    'data/.meta',
    'data/.sessions',
    'data/.rate',
    'config',
    'logs',
    'lang',
    'admin',
    'public',
    'assets/css',
    'assets/js'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "✓ Created: $dir\n";
    }
}

// Create .htaccess for data protection
$htaccess_data = "Order Deny,Allow\nDeny from all";
file_put_contents('data/.htaccess', $htaccess_data);
file_put_contents('config/.htaccess', $htaccess_data);
file_put_contents('logs/.htaccess', $htaccess_data);

// Create default config
if (!file_exists('config/app.json')) {
    $config = [
        'site_name' => 'Private FileHost',
        'admin_email' => 'admin@example.com',
        'admin_password' => password_hash('admin123', PASSWORD_BCRYPT),
        'max_file_size' => 524288000, // 500MB in bytes
        'allowed_extensions' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'rar', '7z', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mp3', 'txt', 'csv'],
        'default_expiry_hours' => 168, // 7 days
        'captcha_enabled' => true,
        'rate_limit_downloads' => 10,
        'rate_limit_hours' => 1,
        'bandwidth_limit_kbps' => 0, // 0 = unlimited
        'default_language' => 'en',
        'timezone' => 'UTC'
    ];
    file_put_contents('config/app.json', json_encode($config, JSON_PRETTY_PRINT));
    echo "✓ Created default config (admin@example.com / admin123)\n";
    echo "⚠️  CHANGE DEFAULT PASSWORD IMMEDIATELY!\n";
}

// Create index.php router
$router = '<?php
session_start();
require_once "includes/functions.php";

$uri = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$uri = trim($uri, "/");

if (empty($uri) || $uri === "index.php") {
    header("Location: /admin/");
    exit;
}

if (strpos($uri, "admin") === 0) {
    require "admin/index.php";
} elseif (preg_match("/^[a-zA-Z0-9]{6}$/", $uri)) {
    require "public/download.php";
} else {
    http_response_code(404);
    echo "404 - Not Found";
}
';

file_put_contents('index.php', $router);
echo "✓ Created index.php router\n";

echo "\n✅ Setup complete! Access admin panel at: /admin/\n";
echo "📧 Email: admin@example.com\n";
echo "🔑 Password: admin123\n";
?>
