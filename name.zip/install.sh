#!/bin/bash

# Private FileHost - Quick Installation Script
# For CWP (CentOS Web Panel) and Apache servers

echo "=================================="
echo "  Private FileHost Installer"
echo "=================================="
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Please run with sudo or as root"
    exit 1
fi

# Check PHP version
PHP_VERSION=$(php -r 'echo PHP_VERSION;' 2>/dev/null)
if [ -z "$PHP_VERSION" ]; then
    echo "❌ PHP not found. Please install PHP 8.1 or higher"
    exit 1
fi

echo "✓ PHP Version: $PHP_VERSION"

# Check required PHP extensions
REQUIRED_EXTENSIONS=("fileinfo" "json" "mbstring" "zip")
MISSING_EXTENSIONS=()

for ext in "${REQUIRED_EXTENSIONS[@]}"; do
    if ! php -m | grep -q "^$ext$"; then
        MISSING_EXTENSIONS+=("$ext")
    fi
done

if [ ${#MISSING_EXTENSIONS[@]} -gt 0 ]; then
    echo "❌ Missing PHP extensions: ${MISSING_EXTENSIONS[*]}"
    echo "   Install with: yum install php-${MISSING_EXTENSIONS[*]}"
    exit 1
fi

echo "✓ All required PHP extensions found"

# Get installation directory
read -p "Enter installation directory (e.g., /home/username/public_html/files): " INSTALL_DIR

if [ -z "$INSTALL_DIR" ]; then
    echo "❌ Installation directory is required"
    exit 1
fi

# Create directory if it doesn't exist
if [ ! -d "$INSTALL_DIR" ]; then
    mkdir -p "$INSTALL_DIR"
    echo "✓ Created directory: $INSTALL_DIR"
fi

# Copy files (assuming script is in the same directory as files)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "📦 Copying files..."

cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
echo "✓ Files copied"

# Set permissions
echo "🔒 Setting permissions..."
cd "$INSTALL_DIR"

chmod 755 .
chmod 755 admin/ public/ includes/ lang/ assets/ -R
chmod 755 data/ config/ logs/ backups/ -R
chmod 644 .htaccess
chmod 644 config/app.json 2>/dev/null || true

echo "✓ Permissions set"

# Get domain information
read -p "Enter your domain (e.g., files.example.com): " DOMAIN

if [ -z "$DOMAIN" ]; then
    echo "⚠️  No domain provided, skipping Apache configuration"
else
    # Create Apache virtual host configuration
    VHOST_FILE="/etc/httpd/conf.d/${DOMAIN}.conf"
    
    cat > "$VHOST_FILE" << EOF
<VirtualHost *:80>
    ServerName $DOMAIN
    DocumentRoot $INSTALL_DIR
    
    <Directory $INSTALL_DIR>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        # PHP settings
        php_value upload_max_filesize 500M
        php_value post_max_size 500M
        php_value max_execution_time 300
        php_value max_input_time 300
    </Directory>
    
    # Protect sensitive directories
    <DirectoryMatch "^$INSTALL_DIR/(data|config|logs|includes)">
        Require all denied
    </DirectoryMatch>
    
    ErrorLog /var/log/httpd/${DOMAIN}-error.log
    CustomLog /var/log/httpd/${DOMAIN}-access.log combined
</VirtualHost>
EOF
    
    echo "✓ Apache virtual host created: $VHOST_FILE"
    
    # Test Apache configuration
    if httpd -t 2>/dev/null || apachectl configtest 2>/dev/null; then
        echo "✓ Apache configuration is valid"
        
        # Restart Apache
        systemctl restart httpd 2>/dev/null || service httpd restart 2>/dev/null
        echo "✓ Apache restarted"
    else
        echo "⚠️  Apache configuration test failed. Please check manually."
    fi
fi

# Check if mod_rewrite is enabled
if httpd -M 2>/dev/null | grep -q rewrite_module || apache2ctl -M 2>/dev/null | grep -q rewrite_module; then
    echo "✓ mod_rewrite is enabled"
else
    echo "⚠️  mod_rewrite not detected. Enable it with:"
    echo "   a2enmod rewrite (Debian/Ubuntu)"
    echo "   Or ensure LoadModule rewrite_module modules/mod_rewrite.so is in httpd.conf"
fi

# Initialize setup
echo ""
echo "🚀 Running setup script..."
cd "$INSTALL_DIR"
php setup.php

echo ""
echo "=================================="
echo "  Installation Complete! 🎉"
echo "=================================="
echo ""
echo "📍 Installation Directory: $INSTALL_DIR"
echo "🌐 Access URL: http://$DOMAIN/admin/"
echo ""
echo "🔐 Default Login:"
echo "   Email: admin@example.com"
echo "   Password: admin123"
echo ""
echo "⚠️  IMPORTANT NEXT STEPS:"
echo "   1. Visit http://$DOMAIN/admin/ and login"
echo "   2. Go to Settings and CHANGE THE PASSWORD"
echo "   3. Delete the setup.php file:"
echo "      rm $INSTALL_DIR/setup.php"
echo ""
echo "📖 Documentation: $INSTALL_DIR/README.md"
echo ""

# SSL Certificate suggestion
if [ ! -z "$DOMAIN" ]; then
    echo "🔒 To enable HTTPS (recommended):"
    echo "   certbot --apache -d $DOMAIN"
    echo ""
fi

echo "✅ Installation successful!"
