<?php

function load_config() {
    return json_decode(file_get_contents(__DIR__ . '/../config/app.json'), true);
}

function save_config($config) {
    file_put_contents(__DIR__ . '/../config/app.json', json_encode($config, JSON_PRETTY_PRINT));
}

function is_logged_in() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /admin/login.php');
        exit;
    }
}

function generate_slug($length = 6) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    do {
        $slug = '';
        for ($i = 0; $i < $length; $i++) {
            $slug .= $chars[random_int(0, strlen($chars) - 1)];
        }
    } while (slug_exists($slug));
    return $slug;
}

function slug_exists($slug) {
    $files = glob(__DIR__ . '/../data/.meta/*.json');
    foreach ($files as $file) {
        $meta = json_decode(file_get_contents($file), true);
        if ($meta['slug'] === $slug) {
            return true;
        }
    }
    return false;
}

function generate_hash($filepath) {
    return hash_file('sha256', $filepath);
}

function get_file_by_slug($slug) {
    $files = glob(__DIR__ . '/../data/.meta/*.json');
    foreach ($files as $file) {
        $meta = json_decode(file_get_contents($file), true);
        if ($meta['slug'] === $slug) {
            return $meta;
        }
    }
    return null;
}

function get_all_files() {
    $files = glob(__DIR__ . '/../data/.meta/*.json');
    $result = [];
    foreach ($files as $file) {
        $meta = json_decode(file_get_contents($file), true);
        $result[] = $meta;
    }
    usort($result, function($a, $b) {
        return $b['created'] - $a['created'];
    });
    return $result;
}

function save_file_meta($hash, $data) {
    $meta_path = __DIR__ . '/../data/.meta/' . $hash . '.json';
    file_put_contents($meta_path, json_encode($data, JSON_PRETTY_PRINT));
}

function delete_file_by_hash($hash) {
    $meta_path = __DIR__ . '/../data/.meta/' . $hash . '.json';
    if (file_exists($meta_path)) {
        $meta = json_decode(file_get_contents($meta_path), true);
        if (file_exists($meta['path'])) {
            unlink($meta['path']);
        }
        unlink($meta_path);
        return true;
    }
    return false;
}

function format_bytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}

function check_rate_limit($ip, $config) {
    if ($config['rate_limit_downloads'] == 0) return true;
    
    $rate_file = __DIR__ . '/../data/.rate/' . md5($ip) . '.json';
    $now = time();
    $limit_seconds = $config['rate_limit_hours'] * 3600;
    
    if (file_exists($rate_file)) {
        $rate_data = json_decode(file_get_contents($rate_file), true);
        $rate_data['downloads'] = array_filter($rate_data['downloads'], function($timestamp) use ($now, $limit_seconds) {
            return ($now - $timestamp) < $limit_seconds;
        });
        
        if (count($rate_data['downloads']) >= $config['rate_limit_downloads']) {
            return false;
        }
        
        $rate_data['downloads'][] = $now;
    } else {
        $rate_data = ['downloads' => [$now]];
    }
    
    file_put_contents($rate_file, json_encode($rate_data));
    return true;
}

function log_access($slug, $action, $details = '') {
    $log_file = __DIR__ . '/../logs/' . date('Y-m-d') . '.log';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] IP: $ip | Action: $action | Slug: $slug | UA: $ua | Details: $details\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

function is_expired($expiry_timestamp) {
    return $expiry_timestamp > 0 && time() > $expiry_timestamp;
}

function verify_password($input, $hash) {
    return password_verify($input, $hash);
}

function get_mime_type($filepath) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $filepath);
    finfo_close($finfo);
    return $mime;
}

function can_preview($mime) {
    $previewable = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf',
        'text/plain', 'text/html', 'text/css', 'text/javascript'
    ];
    return in_array($mime, $previewable);
}

function sanitize_filename($filename) {
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    return substr($filename, 0, 255);
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function load_language($lang = 'en') {
    $lang_file = __DIR__ . '/../lang/' . $lang . '.json';
    if (file_exists($lang_file)) {
        return json_decode(file_get_contents($lang_file), true);
    }
    return json_decode(file_get_contents(__DIR__ . '/../lang/en.json'), true);
}

function t($key, $lang_data) {
    return $lang_data[$key] ?? $key;
}

function cleanup_expired_files() {
    $files = glob(__DIR__ . '/../data/.meta/*.json');
    $deleted = 0;
    foreach ($files as $file) {
        $meta = json_decode(file_get_contents($file), true);
        if (is_expired($meta['expiry'])) {
            delete_file_by_hash($meta['hash']);
            $deleted++;
        }
    }
    return $deleted;
}

function get_total_storage_size() {
    $total = 0;
    $files = glob(__DIR__ . '/../data/uploads/*/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            $total += filesize($file);
        }
    }
    return $total;
}

function get_stats() {
    $files = get_all_files();
    $total_downloads = 0;
    $total_size = 0;
    
    foreach ($files as $file) {
        $total_downloads += $file['download_count'];
        $total_size += $file['size'];
    }
    
    return [
        'total_files' => count($files),
        'total_downloads' => $total_downloads,
        'total_size' => $total_size,
        'total_size_formatted' => format_bytes($total_size)
    ];
}
