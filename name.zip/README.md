# 📁 Private File Hosting System

A secure, lightweight PHP file hosting system with no database required. Perfect for sharing files privately with your followers.

## ✨ Features

### Core Features
- ✅ **Single Admin Control** - No public registration, admin-only access
- ✅ **Drag & Drop Upload** - Modern file upload with folder support
- ✅ **No Database** - All data stored in JSON files
- ✅ **Short Links** - Auto-generated 6-character slugs (e.g., `yourdomain.com/aBc123`)
- ✅ **Link Customization** - Custom slugs, expiry, passwords, download limits
- ✅ **File Preview** - Images, PDFs, and text files preview in browser
- ✅ **Multi-language** - Arabic, English, French support

### Security Features
- 🔒 **Password Protection** - Optional per-file passwords
- 🔒 **Rate Limiting** - IP-based download limits
- 🔒 **CAPTCHA** - Math challenge to prevent bots
- 🔒 **CSRF Protection** - Form security tokens
- 🔒 **MIME Validation** - File type verification

### Advanced Features
- ⚡ **Bandwidth Throttling** - Limit download speed
- ⚡ **One-time Downloads** - Auto-delete after download
- ⚡ **Expiry System** - Time-based link expiration
- ⚡ **Duplicate Detection** - SHA-256 hash checking
- ⚡ **Bulk Operations** - Select and delete multiple files
- ⚡ **Access Logs** - Track downloads with IP and user agent
- ⚡ **Search & Filter** - Find files quickly

## 📋 Requirements

- **PHP** 8.1 or higher
- **Apache** with mod_rewrite enabled
- **Extensions**: fileinfo, json, mbstring
- **CWP** (CentOS Web Panel) or any Apache hosting

## 🚀 Installation

### 1. Upload Files
```bash
# Upload all files to your web directory
# Example: /home/username/public_html/files/
```

### 2. Set Permissions
```bash
chmod 755 data/ config/ logs/ -R
chmod 644 config/app.json
```

### 3. Run Setup
```bash
# Navigate to: http://yourdomain.com/setup.php
# This creates all required directories and default config
```

### 4. Secure Your Installation
**IMPORTANT:** After setup, delete `setup.php`
```bash
rm setup.php
```

### 5. Login
- URL: `http://yourdomain.com/admin/`
- Email: `admin@example.com`
- Password: `admin123`

**⚠️ Change the default password immediately in Settings!**

## 📁 Directory Structure

```
filehost/
├── admin/                  # Admin panel
│   ├── index.php          # Dashboard
│   ├── login.php          # Login page
│   ├── upload.php         # Upload interface
│   ├── settings.php       # Configuration
│   └── logout.php         # Logout handler
├── public/                 # Public access
│   └── download.php       # Download/preview page
├── includes/               # Core functions
│   └── functions.php      # Main functions library
├── data/                   # Storage (protected)
│   ├── uploads/           # Uploaded files (YYYY/MM/)
│   ├── .meta/             # File metadata (JSON)
│   ├── .sessions/         # PHP sessions
│   └── .rate/             # Rate limit data
├── config/                 # Configuration (protected)
│   └── app.json           # Main config file
├── logs/                   # Access logs (protected)
│   └── YYYY-MM-DD.log     # Daily logs
├── lang/                   # Translations
│   ├── en.json            # English
│   ├── ar.json            # Arabic
│   └── fr.json            # French
└── .htaccess              # URL rewriting & security
```

## 🔧 Configuration

Edit `config/app.json` or use the Settings page:

```json
{
  "site_name": "Private FileHost",
  "admin_email": "admin@example.com",
  "admin_password": "$2y$10$...",
  "max_file_size": 524288000,
  "allowed_extensions": ["pdf", "jpg", "png", "zip", ...],
  "default_expiry_hours": 168,
  "captcha_enabled": true,
  "rate_limit_downloads": 10,
  "rate_limit_hours": 1,
  "bandwidth_limit_kbps": 0,
  "default_language": "en",
  "timezone": "UTC"
}
```

### Key Settings:
- **max_file_size**: Maximum upload size (bytes)
- **allowed_extensions**: Whitelist of file types
- **default_expiry_hours**: Default link expiration (0 = never)
- **rate_limit_downloads**: Max downloads per IP per period
- **bandwidth_limit_kbps**: Download speed limit (0 = unlimited)

## 📖 Usage Guide

### Uploading Files

1. Go to **Admin → Upload**
2. Drag & drop files or click to browse
3. Configure options:
   - **Custom Slug**: Your own link (e.g., `my-report`)
   - **Expiry**: Hours until link expires (0 = never)
   - **Password**: Optional password protection
   - **Max Downloads**: Limit total downloads (0 = unlimited)
4. Click **Upload**
5. Copy the generated link

### Managing Files

- **Dashboard**: View all files with stats
- **Search**: Filter files by name
- **Copy Link**: Click to copy share URL
- **Delete**: Remove single file
- **Bulk Delete**: Select multiple files to delete
- **Cleanup Expired**: Remove all expired files

### Sharing Links

Generated links format: `https://yourdomain.com/aBc123`

Features:
- Short, easy to share
- Optional password protection (🔒 icon in dashboard)
- Auto-expires based on settings
- One-time download option
- Preview before download

### Link Access Flow

1. **User visits link** → Preview page shown
2. **If password protected** → Password prompt
3. **If CAPTCHA enabled** → Math challenge
4. **Rate limit check** → IP-based limiting
5. **Download/Preview** → File delivered

## 🔐 Security Best Practices

### 1. Change Default Credentials
```
Settings → Admin Account → New Password
```

### 2. Use Strong Passwords
- Minimum 12 characters
- Mix uppercase, lowercase, numbers, symbols

### 3. Enable HTTPS
```bash
# Get free SSL with Let's Encrypt
certbot --apache -d yourdomain.com
```

### 4. Restrict PHP Extensions
Add to `.htaccess`:
```apache
<Files "*.php">
    Order Deny,Allow
    Deny from all
</Files>
<FilesMatch "^(index|admin|public)\.php$">
    Allow from all
</FilesMatch>
```

### 5. Regular Backups
```bash
# Backup entire data directory
tar -czf backup-$(date +%Y%m%d).tar.gz data/ config/

# Or use the built-in backup (coming soon)
```

### 6. Monitor Logs
Check `logs/YYYY-MM-DD.log` for suspicious activity:
```bash
tail -f logs/$(date +%Y-%m-%d).log
```

## 🌍 Multi-Language Support

Supported languages:
- 🇺🇸 English (en)
- 🇸🇦 Arabic (ar) - RTL support
- 🇫🇷 French (fr)

Change language:
1. **Settings → General → Default Language**
2. Or edit `config/app.json`:
   ```json
   "default_language": "ar"
   ```

Add new language:
1. Copy `lang/en.json` to `lang/xx.json`
2. Translate all values
3. Add to Settings dropdown

## 🔧 Troubleshooting

### Upload fails / File too large
**Solution:**
1. Edit `.htaccess`:
   ```apache
   php_value upload_max_filesize 500M
   php_value post_max_size 500M
   ```
2. Or in `php.ini`:
   ```ini
   upload_max_filesize = 500M
   post_max_size = 500M
   max_execution_time = 300
   ```
3. Restart Apache:
   ```bash
   systemctl restart httpd
   ```

### Links return 404
**Solution:**
1. Enable mod_rewrite:
   ```bash
   a2enmod rewrite
   systemctl restart apache2
   ```
2. Check `.htaccess` exists and is readable
3. Verify Apache allows .htaccess overrides:
   ```apache
   <Directory /var/www/html>
       AllowOverride All
   </Directory>
   ```

### Permission denied errors
**Solution:**
```bash
chmod 755 data/ config/ logs/ -R
chown www-data:www-data data/ config/ logs/ -R
```

### Session errors
**Solution:**
```bash
mkdir -p data/.sessions
chmod 755 data/.sessions
# Edit php.ini:
session.save_path = "/path/to/filehost/data/.sessions"
```

## 🚀 Performance Tips

### 1. Enable OPcache
Edit `php.ini`:
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=10000
```

### 2. Use CDN for Static Assets
Replace Pico CSS CDN with local copy for faster loads.

### 3. Regular Cleanup
Run periodically:
```bash
# Clean expired files
php -r "require 'includes/functions.php'; cleanup_expired_files();"

# Clean old logs (older than 30 days)
find logs/ -name "*.log" -mtime +30 -delete

# Clean old rate limit data
find data/.rate/ -name "*.json" -mtime +7 -delete
```

### 4. Optimize File Storage
```bash
# Move old files to archive (outside web root)
find data/uploads/ -mtime +90 -type f -exec mv {} /backup/archive/ \;
```

## 📊 Monitoring & Analytics

### View Statistics
Dashboard shows:
- Total files uploaded
- Total downloads
- Storage used

### Access Logs
Format: `[timestamp] IP: xxx.xxx.xxx.xxx | Action: download | Slug: aBc123 | UA: Mozilla/5.0...`

Parse logs:
```bash
# Top downloaders
cat logs/*.log | grep download | cut -d'|' -f2 | sort | uniq -c | sort -rn | head -10

# Most popular files
cat logs/*.log | grep download | cut -d'|' -f4 | sort | uniq -c | sort -rn | head -10
```

## 🆘 Support

### Common Issues
1. **Can't login**: Clear browser cache and cookies
2. **Upload fails**: Check PHP upload settings
3. **404 on links**: Verify mod_rewrite enabled
4. **Slow downloads**: Disable bandwidth throttle or increase limit

### Debug Mode
Enable in `includes/functions.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

## 📝 License

This project is open-source and free to use for personal and commercial purposes.

## 🙏 Credits

Built with:
- **PHP 8.1+**
- **Pico CSS** - Minimal CSS framework
- **Apache mod_rewrite**

---

**Made with ❤️ for private file sharing**
